package test;

import java.util.Calendar;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Test;

public class Client {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("resources/spring.xml");
		Test t=(Test)ac.getBean("t");
		Test t1=(Test)ac.getBean("t");
		System.out.println(t==t1);
		Calendar c=(Calendar)ac.getBean("c");
		Calendar c1=(Calendar)ac.getBean("c");
		System.out.println(c==c1);
		//System.out.println(c.getCalendarType());
		
				
	}

}

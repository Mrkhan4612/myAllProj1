package beans;

import java.lang.reflect.Method;

import org.springframework.beans.factory.support.MethodReplacer;

public class NewCalculateIntrest implements MethodReplacer {

	@Override
	public Object reimplement(Object o, Method m, Object[] parameter) throws Throwable {
		System.out.println("NewCalculateIntrest class new calculateIntrest implimentation");
		return o;
	}

}

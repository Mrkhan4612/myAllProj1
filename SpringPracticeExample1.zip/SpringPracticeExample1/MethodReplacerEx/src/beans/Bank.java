package beans;

public class Bank 
{
	public void deposite()
	{
		System.out.println("deposite method in bank");
	
	}
	
	public void withdraw()
	{
		System.out.println("withdraw method in bank");
	}

	public void calculateIntrest()
	{
		System.out.println("calculateIntrest method in bank");
	}

}

package controller;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.ParameterizableViewController;
import org.springframework.web.servlet.mvc.UrlFilenameViewController;
import org.springframework.web.servlet.mvc.support.ControllerClassNameHandlerMapping;


public class HelloController extends ParameterizableViewController {
	

	//UrlFilenameViewController
	//or we can go through hadleRequestInternal
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest req, HttpServletResponse res) throws Exception {
	
		//ControllerClassNameHandlerMapping
		String name=req.getParameter("name");
		java.util.HashMap m=new java.util.HashMap();
		m.put("msg","Hello......using controller class name mappings ...... and Abstract controller..."+name);
		ModelAndView mav=new ModelAndView(getViewName(),m);
		return mav;
	}

}

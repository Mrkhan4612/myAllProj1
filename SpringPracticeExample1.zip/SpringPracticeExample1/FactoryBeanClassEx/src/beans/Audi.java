package beans;

public class Audi implements Car {

	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("safedrive 100kmph in audi");
	}

}

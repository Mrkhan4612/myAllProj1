package beans;

import org.springframework.beans.factory.FactoryBean;

public class CarFactory implements FactoryBean {
	public String carname;

	public  void setCarname(String carname) {
		this.carname = carname;
	}
	
	@Override
	public Object getObject() throws Exception {
		// TODO Auto-generated method stub
		Car c=(Car)Class.forName(carname).newInstance();
		return c;
	}

	@Override
	public Class getObjectType() {
		// TODO Auto-generated method stub
		
		return Car.class;
	}
	
	public boolean isSingleton() {
	
		return true;
		
	}
	

}

package beans;

public class Truk {
	
	public Engine myTrukEngine()
	{
		Engine e=new Engine();
		e.setName("Eicher");
		return e;
		
	}

}

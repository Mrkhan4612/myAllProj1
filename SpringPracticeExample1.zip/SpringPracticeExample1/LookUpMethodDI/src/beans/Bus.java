package beans;

abstract public class Bus 
{
	abstract public Engine myBusEngine();
}

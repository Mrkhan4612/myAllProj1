package beans;

public class Test2  {

	public void init()  
	{
	
	System.out.println("Tets2 init....");
	}
	public void destroy() 	
	{
	
		System.out.println("Test2 destroy.....");
	}
}

package beans;


public class Test1  {

		public void init()  
		{
		
		System.out.println("Tets1 init....");
		}
		public void destroy() 	
		{
		
			System.out.println("Test1 destroy.....");
		}

}

package beans;

public class Test {

	private Test() {
		System.out.println("HELLWORLD private Constructor");

	}

}

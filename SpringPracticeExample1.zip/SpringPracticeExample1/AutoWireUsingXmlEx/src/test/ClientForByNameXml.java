package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Car;

public class ClientForByNameXml {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String files[]=new String[] {"resources/car.xml","resources/engine.xml"};
		ApplicationContext ac=new ClassPathXmlApplicationContext("resources/springUsing_byName.xml");
		Car car=(Car)ac.getBean("c");
		car.printData();
	}

}

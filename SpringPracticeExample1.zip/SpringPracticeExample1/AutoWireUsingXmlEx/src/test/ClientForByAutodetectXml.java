package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Bus;
import beans.Car;

public class ClientForByAutodetectXml {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String files[]=new String[] {"resources/car.xml","resources/engine.xml"};
		ApplicationContext ac=new ClassPathXmlApplicationContext("resources/springUsing_byAutodetect.xml");
	Bus bus=(Bus)ac.getBean("b");
		bus.printData();
	}

}

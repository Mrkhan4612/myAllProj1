package beans;

public class Engine {
	private int modelYear;

	public int getModelYear() {
		return modelYear;
	}

	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}

	
	
}

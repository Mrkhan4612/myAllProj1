package beans;

public class Bus {
	private Engine engine;
	
	public Bus(Engine engine)
	{
		System.out.println("parameter Bus contructor.....");
		this.engine=engine;
		
	}
	public void printData()
	{
		System.out.println("Bus Eng Model Year="+engine.getModelYear());
	}
}

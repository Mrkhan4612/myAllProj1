package test;



import javax.annotation.Resources;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import beans.Test;

public class Client {

	public static void main(String[] args) {
	Resource rs=new ClassPathResource("resources/spring.xml");
	BeanFactory bf=new XmlBeanFactory(rs);
	Object o=bf.getBean("t");
	Test t=(Test)o;
	t.hello();
	}

}

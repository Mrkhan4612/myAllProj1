package beans;


//import org.springframework.stereotype.Component;

//@Component
public class Engine {
	
	private int modelYear;

	public int getModelYear() 
	{
		return modelYear; 
		}
 
	public void setModelYear(int modelYear) 
	{
		this.modelYear = modelYear; 
		
	}
	
}

package beans;

public class Honda implements Car {

	
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("safedrive for 80kmph in Honda");
	}

}

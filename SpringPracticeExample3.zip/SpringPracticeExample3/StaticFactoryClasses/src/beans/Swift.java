package beans;

public class Swift implements Car {

	@Override
	public void drive() {
		System.out.println("safeDrive for 120 kmph in Swift");

	}

}

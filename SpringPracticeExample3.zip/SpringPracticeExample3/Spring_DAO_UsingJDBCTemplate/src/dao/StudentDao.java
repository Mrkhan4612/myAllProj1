package dao;

import java.util.List;

import model.Student;

public interface StudentDao {
	public int save(Student std)throws Exception;
	public boolean update(Student std)throws Exception;
	public boolean delete(Student std)throws Exception;
	public Student findById(int id)throws Exception;
	public Student findByNamr(String name)throws Exception;
	public Student findByEmail(String Email)throws Exception;
	public Student findByaddress(String address)throws Exception;
	public List<Student> findAll()throws Exception;
	
	

}

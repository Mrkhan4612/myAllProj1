package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import javax.sql.DataSource;

import model.Student;

public class StudentDaoImpl implements StudentDao {
 
	private DataSource ds;
	public void setDs(DataSource ds)
	{
		this.ds=ds;
	}
	@Override
	public int save(Student std) throws Exception {
		Connection con=ds.getConnection();
		PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?)");
		ps.setInt(1, std.getId());
		ps.setString(2,std.getName());
		ps.setString(3, std.getEmail());
		ps.setString(4,std.getAddress());
		int i=ps.executeUpdate();
		con.close();
		
		return i;
	}

	@Override
	public boolean update(Student s) throws Exception {
		Connection con=ds.getConnection();
		con.close();
		return false;
	}

	@Override
	public boolean delete(Student s) throws Exception {
		Connection con=ds.getConnection();
		con.close();
		return false;
	}

	@Override
	public Student findById(int id) throws Exception {
		Connection con=ds.getConnection();
		con.close();
		return null;
	}

	@Override
	public Student findByNamr(String name) throws Exception {
		Connection con=ds.getConnection();
		con.close();
		return null;
	}

	@Override
	public Student findByEmail(String Email) throws Exception {
		Connection con=ds.getConnection();
		con.close();
		return null;
	}

	@Override
	public Student findByaddress(String address) throws Exception {
		Connection con=ds.getConnection();
		con.close();
		return null;
	}

	@Override
	public List<Student> findAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}

package business;

import model.Student;

public interface StudentBo {
	public int createStudent(Student sdt)throws Exception;
	public boolean updateStudent(Student sdt)throws Exception;
	public boolean deleteStudent(Student sdt)throws Exception;

}

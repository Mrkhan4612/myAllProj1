package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import org.springframework.web.servlet.mvc.Controller;

public class HelloController extends AbstractController {
	//here we are using Abstract Controller class

	//or we can go through this handle request method
	/**
	@Override
	public ModelAndView handleRequest(HttpServletRequest req, HttpServletResponse res) throws Exception {
		String name=req.getParameter("name");
		java.util.HashMap m=new java.util.HashMap();
		m.put("msg","Hello......using controller class name mappings ...... and Abstract controller..."+name);
		ModelAndView mav=new ModelAndView("success",m);
		
		return mav;	}
*/
	//or we can go through hadleRequestInternal
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest req, HttpServletResponse res) throws Exception {
		String name=req.getParameter("name");
		java.util.HashMap m=new java.util.HashMap();
		m.put("msg","Hello......using controller class name mappings ...... and Abstract controller..."+name);
		ModelAndView mav=new ModelAndView("success",m);
		return mav;
	}

}

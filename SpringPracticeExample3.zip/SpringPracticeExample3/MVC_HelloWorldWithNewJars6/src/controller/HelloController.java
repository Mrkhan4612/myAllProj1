package controller;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.ParameterizableViewController;


public class HelloController extends ParameterizableViewController {
	

	
	//or we can go through hadleRequestInternal
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest req, HttpServletResponse res) throws Exception {
	
	
		String name=req.getParameter("name");
		java.util.HashMap m=new java.util.HashMap();
		m.put("msg","Hello......using controller class name mappings ...... and ParameterizableViewController class..."+name);
		ModelAndView mav=new ModelAndView(getViewName(),m);
		return mav;
	}

}

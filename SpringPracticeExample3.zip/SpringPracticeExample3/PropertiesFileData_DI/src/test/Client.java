package test;





import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Cp;

public class Client {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/spring.xml"); 
		Cp cp=(Cp)ap.getBean("cp");
		cp.createConnection();
	}

}

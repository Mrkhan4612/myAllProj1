package beans;

import java.util.Properties;
import java.util.Set;

public class Test {
	private Properties dbdriver;

	public void setDbdriver(Properties dbdriver) {
		this.dbdriver = dbdriver;
	} 

	public void printData()
	{
	Set keys=dbdriver.keySet();
		for(Object key:keys)
		{
			System.out.println(key+":"+dbdriver.getProperty(key.toString()));
		}
	}
}

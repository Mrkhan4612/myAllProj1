package beans;

public class Car {
	private static String carName;
	
	
	public static void setCarName(String carName) {
		Car.carName = carName;
	}


	public void printData()
	{
		System.out.println("Car Name="+carName);
	
		
	}

}

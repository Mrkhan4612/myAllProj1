package business;

import dao.StudentDao;
import model.Student;

public class StudentBoImpl implements StudentBo {
	
	private StudentDao dao;
	public void setDao(StudentDao dao) {
		this.dao=dao;
	}
	

	@Override
	public int createStudent(Student sdt) throws Exception {
		
		return dao.save(sdt);
	}

	@Override
	public boolean updateStudent(Student sdt) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteStudent(Student sdt) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

}

package beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Date;

public class Test1 {

	public static void main(String[] args) {
		
		System.out.println("jdbc connection from database");
		Date d1=new Date();
		for(int i=0;i<200000;i++)
		{
			try {
				
				Class.forName("oracle.jdbc.OracleDriver");
				Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","pathan");
				System.out.println(con+":"+i);
				con.close();
				
			}catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
			Date d2=new Date();
			System.out.println("starts time:"+d1);
			System.out.println("end time:"+d2);
		

	}

}

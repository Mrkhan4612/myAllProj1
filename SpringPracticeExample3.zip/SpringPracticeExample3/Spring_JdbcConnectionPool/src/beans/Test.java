package beans;

import java.sql.Connection;
import java.util.Date;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;

public class Test {
 public static void main(String[] args) {
	BasicDataSource bds=new BasicDataSource();
	bds.setDriverClassName("oracle.jdbc.OracleDriver");
	bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
	bds.setUsername("system");
	bds.setPassword("pathan");
	bds.setMaxActive(15);
	bds.setMaxIdle(5);
	bds.setMaxWait(1000*5);
	
	//System.out.println("jdbc connection from database");
	Date d1=new Date();
	for(int i=0;i<200000;i++)
	{
		try {
			
			Connection con=bds.getConnection();
			System.out.println(con+":"+i);
			con.close();
			
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
		Date d2=new Date();
		System.out.println("starts time:"+d1);
		System.out.println("end time:"+d2);
		
		
}
}

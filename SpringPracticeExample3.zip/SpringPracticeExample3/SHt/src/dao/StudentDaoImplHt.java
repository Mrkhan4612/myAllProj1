package dao;

import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import model.Student;

public class StudentDaoImplHt implements StudentDaoInterface {
	
private HibernateTemplate ht;
	
	public void setHt(HibernateTemplate ht)
	{
		this.ht=ht;
		
	}
	@Override
	public int save(Student std) {
		int i=(Integer)ht.save(std);
		return i;
	}

	@Override
	public boolean update(Student std) {
		ht.update(std);
		return true;
		}

	@Override
	public boolean delete(Student std) {
		ht.delete(std);
		return true;
		}

	@Override
	public Student findByPk(int pk) {
		Student std=(Student)ht.get(Student.class, pk);
		return std;
	}

	@Override
	public List<Student> findAllUsingHQL() {
		List<Student> list=ht.find("from Student");
		return list;
	}

	@Override
	public List<Student> findAllUsingCriteria() {
		DetachedCriteria dc=DetachedCriteria.forClass(Student.class);
		/**dc.setProjection(projection)dc.add(criterion)*/
		 List<Student> list=ht.findByCriteria(dc);
		return list;	}

}

package dao;

import java.util.List;

import model.Student;

public interface StudentDaoInterface {
	public int save(Student std);
	public boolean update(Student std);
	public boolean delete(Student std);
	public Student findByPk(int pk);
	public List<Student> findAllUsingHQL();
	public List<Student> findAllUsingCriteria();
	
	

}
